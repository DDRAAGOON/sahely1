import 'package:flutter/material.dart';

/// App-level role. Drives badge colour/label across the app.
enum Role { renter, owner, broker }

extension RoleX on Role {
  String get label => switch (this) {
        Role.renter => 'Renter',
        Role.owner => 'Property Owner',
        Role.broker => 'Broker',
      };

  String get shortLabel => switch (this) {
        Role.renter => 'Renter',
        Role.owner => 'Owner',
        Role.broker => 'Broker',
      };
}

class Property {
  const Property({
    required this.name,
    required this.area,
    required this.image,
    required this.price,
    required this.rating,
    required this.reviews,
    this.type = 'Villa',
    this.beds = 3,
    this.guests = 6,
    this.tags = const [],
    this.petsOk = true,
    this.minutesToBeach,
    this.guestFavourite = false,
    this.saved = false,
  });

  final String name;
  final String area; // compound / location
  final String image;
  final int price; // EGP per night
  final double rating;
  final int reviews;
  final String type;
  final int beds;
  final int guests;
  final List<String> tags;
  final bool petsOk;
  final int? minutesToBeach;
  final bool guestFavourite;
  final bool saved;
}

class ServiceItem {
  const ServiceItem(this.name, this.fromPrice, this.gradient);
  final String name;
  final String fromPrice;
  final List<Color> gradient;
}
