import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sahely/core/providers/currency_provider.dart';
import 'package:sahely/core/theme/app_colors.dart';

class StickyBottomBar extends StatelessWidget {
  final int pricePerNight;
  final VoidCallback onBookNowTap;

  const StickyBottomBar({
    super.key,
    required this.pricePerNight,
    required this.onBookNowTap,
  });

  @override
  Widget build(BuildContext context) {
    final currencyProvider = context.watch<CurrencyProvider>();
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.navy.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // Price
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    currencyProvider.formatPrice(pricePerNight.toDouble()),
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: AppColors.navy,
                      fontFamily: 'DM Sans',
                    ),
                  ),
                  const Text(
                    '/ night',
                    style: TextStyle(
                      fontSize: 13,
                      color: AppColors.secondary,
                      fontFamily: 'DM Sans',
                    ),
                  ),
                ],
              ),
            ),

            // Book Now Button
            const SizedBox(width: 16),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: onBookNowTap,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.navy,
                  foregroundColor: AppColors.white,
                  minimumSize: const Size(140, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'Book Now',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'DM Sans',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
